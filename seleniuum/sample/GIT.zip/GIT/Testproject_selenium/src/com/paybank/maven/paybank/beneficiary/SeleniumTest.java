package com.paybank.maven.paybank.beneficiary;

import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SeleniumTest {
	public static void main(String [] args) {
		try {
			//System.setProperty("webdriver.gecko.driver", "/home/ec2-user/selenium/drivers/geckodriver");
			
			String URL2 = "https://pay-bank-hello.cfapps.io/#/login";
			
			DesiredCapabilities dc = DesiredCapabilities.firefox();
			dc.setCapability("marionette", false);
			FirefoxOptions fo = new FirefoxOptions(dc);
						
			WebDriver driver = new RemoteWebDriver(new URL("http://ec2-54-144-30-209.compute-1.amazonaws.com/wd/hub"), fo);

			driver.get(URL2);
			String response = driver.getPageSource();
			
			// get All functions

			System.out.println("PageSource " + response);

			driver.quit();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}