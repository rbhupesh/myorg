package com.paybank.maven.paybank.beneficiary;
 

import java.net.MalformedURLException;

//import static org.junit.Assert.*;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.util.Asserts;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class FTOneTests {

	@Test
	public void test() {

		String appURL = "https://pay-bank-hello.cfapps.io/#/login";


		try {
			URL firfoxvmURL = new URL("http://ec2-54-144-30-209.compute-1.amazonaws.com/wd/hub");
			FirefoxOptions fo = new FirefoxOptions();
			fo.setCapability("marionette", false);

			WebDriver driver = new RemoteWebDriver(firfoxvmURL, fo);
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			driver.get(appURL);
			driver.manage().window().maximize();
			String response = driver.getPageSource();

			// get All functions

			System.out.println("PageSource " + response);

			driver.findElement(By.id("name")).sendKeys("rbhupesh");
			System.out.println("Name entered");

			driver.findElement(By.id("pass")).sendKeys("rbhupesh123");
			System.out.println("Password entered");
			driver.findElement(By.className("btn")).click();
			System.out.println("Btn clicked");
			Thread.sleep(1000);

			System.out
			.println("ELement visibility" + driver.findElement(By.cssSelector(".navbar-toggle")).isDisplayed());
			if (driver.findElement(By.cssSelector(".navbar-toggle")).isDisplayed())
				driver.findElement(By.cssSelector(".navbar-toggle")).click();

			driver.findElement(By.cssSelector("a[ui-sref='addBeneficiary']")).click();

			System.out.println("Add beneficiary clicked");
			Thread.sleep(1000);
			driver.findElement(By.id("name")).sendKeys("Triveni");
			System.out.println(driver.findElement(By.id("name")).getAttribute("placeholder"));
			System.out.println("Account name entered");
			Thread.sleep(1000);
			WebElement accNumber = driver.findElement(By.id("acNumber"));
			accNumber.sendKeys("100010103");

			System.out.println("Number entered");
			Thread.sleep(1000);

			Thread.sleep(1000);
			List<WebElement> listAccountNumber;
			ArrayList<String> listAccNumString = new ArrayList<String>();

			listAccountNumber = driver.findElements(By.xpath("//table/tbody/tr"));
			System.out.println(listAccountNumber.size());
			for (int i = 1; i <= listAccountNumber.size(); i++) {
				String txt = (driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[2]")).getText());
				listAccNumString.add(txt);
				System.out.println(txt);
			}
			System.out.println(listAccNumString);
			if (listAccNumString.contains("100010103")) {
				System.out.println("Fail");
				Asserts.check(!listAccNumString.contains("100010103"), "Failed - Beneficiary Added");
			} else
				System.out.println("Pass");

			driver.quit();
		} catch (MalformedURLException | InterruptedException e) {
			e.printStackTrace();
			org.junit.Assert.fail();		
			
		}
	}
}
